# IEEE Pervasive Magazine Template

This folder is a clean Overleaf starter for the IEEE Pervasive Computing
magazine-style article on embodied UAV voice interaction.

It is intentionally separate from `docs/paper_sensys2027/`.

## Scope

- Early framing / experience article, not a full systems paper.
- Use a generic article title first; do not commit to the full system-paper name.
- Keep the article under 6000 words, including references, biographies, table
  text, and the 250-word charge per figure/table.
- Keep citations near 20.
- Use limited figures and no equations.
- Preserve deeper technical novelty and broad evaluation for future
  MobiCom/SenSys/TMC work.

## Files

- `main.tex`: root file for Overleaf.
- `references.bib`: starter bibliography file.
- `sections/`: one source file per manuscript section.
- `figures/figure_table_manifest.md`: planned figure/table tracking.
- `notes/meeting_direction_bullets.md`: bullets for advisor discussion.

## Overleaf Setup

1. Upload this folder as a new Overleaf project.
2. Set `main.tex` as the main document.
3. Compile with pdfLaTeX first.
4. Keep paper-facing edits in section files.
5. Keep meeting notes in `notes/`, not in the manuscript body.

## Current Section Plan

1. Introduction
2. Motivation
3. System Frame
4. Evaluation
5. Limitations and Future Work
6. Conclusion

This section plan is appropriate for a lightweight magazine article. If the
paper later becomes a full systems paper, split `System Frame` into architecture,
implementation, and policy/mechanism sections in a separate project.
