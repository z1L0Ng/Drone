# Figure/Table Manifest

Track which figures and tables are planned for the magazine article.

| ID | Type | Draft Title | Source / Evidence Path | Status | Notes |
|---|---|---|---|---|---|
| F1 | Figure | Physical setup or voice-safety pipeline | TBD | planned | Prefer a real setup image if available; otherwise use a clean conceptual diagram. |
| T1 | Table | Voice signal contract | `sections/03_system_frame.tex` | planned | Keep semantics simple: emergency, movement-oriented, unknown/unsupported. |
| T2 | Table | Basic evidence summary | W23 result summaries | planned | Include claim boundaries; do not include every result. |

