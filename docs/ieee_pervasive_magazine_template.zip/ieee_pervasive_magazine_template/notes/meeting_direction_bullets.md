# Meeting Direction Bullets

Use this note for the advisor meeting. Do not paste this file directly into the
manuscript.

## Working Identity

- Early magazine framing article, not a full system paper.
- Use a generic title first, such as:
  - `Voice Safety Signals for Embodied Drone Interaction`
  - `Mediating Voice Input in Embodied UAV Systems`
  - `A Voice Safety Layer for Embodied Drone Interaction`

## Proposed Central Claim

- Voice near an embodied UAV should first become a constrained safety-relevant
  signal, not a direct flight command.
- The article explains the frame and gives basic prototype evidence.
- Deeper policy, control-loop, and deployment novelty should stay for later
  MobiCom/SenSys/TMC work.

## Proposed Sections

1. Introduction
2. Motivation
3. System Frame
4. Evaluation
5. Limitations and Future Work
6. Conclusion

## Advisor Questions

- Should the paper avoid the full project/system name and use a generic framing
  title?
- Is `voice safety signal` the right top-level phrase, or should we use
  `voice safety layer` / `speech-admission layer`?
- Which evidence is enough for a lightweight magazine article?
- Which future novelty must be protected for the longer system paper?
